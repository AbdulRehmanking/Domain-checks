
TRAINED_MODEL = 'models/trained_rf_dga_classifier.sav'
X_TRAIN_SAVED = 'models/Xtrain.pkl'